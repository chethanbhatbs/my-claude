#!/usr/bin/env bash
# My Claude — a private, local view of your Claude Code install.
# Reads ~/.claude on THIS machine only. Nothing is uploaded or shared unless you choose to.
#
#   ./run.sh            # start on http://127.0.0.1:8766
#   ./run.sh 9000       # start on a different port
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "Python 3 is required but not found. Install it, then re-run ./run.sh"
  exit 1
fi

VENV="$DIR/.venv"
if [ ! -x "$VENV/bin/uvicorn" ]; then
  echo "Setting up (one-time, ~20s)…"
  "$PY" -m venv "$VENV"
  "$VENV/bin/pip" install --quiet --upgrade pip
  "$VENV/bin/pip" install --quiet -r "$DIR/requirements.txt"
fi

PORT="${1:-8766}"
# If the port is busy, fall back to the next free one (portable check via the bundled Python).
PORT="$("$VENV/bin/python" - "$PORT" <<'PY'
import socket, sys
start = int(sys.argv[1])
for p in range(start, start + 40):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", p)); print(p); break
    except OSError:
        pass
    finally:
        s.close()
else:
    print(start)
PY
)"
[ "$PORT" != "${1:-8766}" ] && echo "Port ${1:-8766} was busy — using $PORT instead."
URL="http://127.0.0.1:$PORT/p/overview"
echo "My Claude → $URL   (localhost only · Ctrl+C to stop)"
# open the browser only once the server actually responds.
# First run can take a while (venv build + indexing your ~/.claude), so we poll
# the page instead of guessing a delay — avoids the browser opening too early and
# showing "This site can't be reached".
( "$VENV/bin/python" - "$PORT" <<'PY' >/dev/null 2>&1
import sys, time, urllib.request
url = "http://127.0.0.1:%d/p/overview" % int(sys.argv[1])
for _ in range(240):            # wait up to ~2 min for a slow first index
    try:
        urllib.request.urlopen(url, timeout=1); break
    except Exception:
        time.sleep(0.5)
PY
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi ) >/dev/null 2>&1 &

exec "$VENV/bin/uvicorn" myclaude:app --host 127.0.0.1 --port "$PORT" --app-dir "$DIR"
