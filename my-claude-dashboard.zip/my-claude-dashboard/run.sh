#!/usr/bin/env bash
# My Claude — a private, local view of your Claude Code install.
# Reads ~/.claude on THIS machine only. Nothing is uploaded or shared.
#
#   ./run.sh            # start on http://127.0.0.1:8766
#   ./run.sh 9000       # start on a different port
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  echo "Python 3 is required but not found. Install it, then re-run ./run.sh"
  exit 1
fi

VENV="$DIR/.venv"
if [ ! -x "$VENV/bin/uvicorn" ]; then
  echo "Setting up (one-time, ~20s)…"
  "$PY" -m venv "$VENV"
  "$VENV/bin/pip" install --quiet --upgrade pip
  "$VENV/bin/pip" install --quiet -r "$DIR/requirements.txt"
fi

PORT="${1:-8766}"
URL="http://127.0.0.1:$PORT/p/overview"
echo "My Claude → $URL   (localhost only · Ctrl+C to stop)"
# open the browser once the server is up
( sleep 2
  if command -v open >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi ) >/dev/null 2>&1 &

exec "$VENV/bin/uvicorn" myclaude:app --host 127.0.0.1 --port "$PORT" --app-dir "$DIR"
