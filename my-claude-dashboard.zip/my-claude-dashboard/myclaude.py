"""My-Claude — interactive dashboard of your Claude installation (FastAPI replica of the Streamlit app, no Streamlit)."""
import io, json, os, pty, re, select, shutil, signal, subprocess, tempfile, threading, time, zipfile
from urllib.parse import quote
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

HOME = Path.home()
CLAUDE = HOME / ".claude"
SKILL_DIR = Path(__file__).resolve().parent
CONFIG_PATH = SKILL_DIR / "config.json"

CAT_COLOR = {
    "Skills": "#D97757", "Sessions": "#C89968", "Connectors": "#A98DD0",
    "Plugins": "#6DAEA0", "Config": "#8FB06B", "Cache": "#8A8072", "Tasks": "#D08AA0",
}
FAMILY_COLOR = {"opus": "#A98DD0", "sonnet": "#D97757", "haiku": "#6DAEA0", "fable": "#6E8FD1"}

PAGES = ["Overview", "Skills", "MCP & Plugins", "Usage", "History", "System", "Help"]
PAGE_SLUG = {p: re.sub(r"[^a-z0-9]+", "-", p.lower()).strip("-") for p in PAGES}
SLUG_PAGE = {v: k for k, v in PAGE_SLUG.items()}
MCP_SLUG = PAGE_SLUG["MCP & Plugins"]

# old slugs -> current page (keep bookmarks/links working after the revamp)
REDIRECTS = {"token-usage": "usage", "mcp-connectors": MCP_SLUG, "plugins": MCP_SLUG,
             "extensions": MCP_SLUG, "sessions": "history", "search": "history",
             "cleanup": "overview", "config": "system", "history-cache": "history",
             "tasks-plans": "overview", "sunburst": "overview", "graph": "overview", "memory": "system"}

# eyebrow = where each page's data lives (structure as information)
EYEBROW = {
    "Overview": "~/.claude", "Skills": "~/.claude/skills",
    "MCP & Plugins": "settings.json · ~/.claude.json · ~/.claude/plugins", "Usage": "~/.claude/projects · usage",
    "History": "~/.claude/projects · transcripts", "System": "~/.claude · config + memory", "Help": "reference",
}

app = FastAPI(title="My Claude", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=SKILL_DIR / "static"), name="static")
templates = Jinja2Templates(directory=SKILL_DIR / "templates")

# ---------- tiny ttl cache ----------
_CACHE = {}
def ttl_cache(seconds=120):
    def deco(fn):
        def wrap(*a, **k):
            key = (fn.__name__, a, tuple(sorted(k.items())))
            try: hash(key)
            except TypeError: return fn(*a, **k)
            hit = _CACHE.get(key)
            if hit and time.time() - hit[0] < seconds: return hit[1]
            val = fn(*a, **k); _CACHE[key] = (time.time(), val); return val
        wrap.cache_clear = lambda: _CACHE.clear()
        return wrap
    return deco
def clear_cache(): _CACHE.clear()

# ---------- format helpers ----------
def fmt_size(n):
    if not n: return "0 B"
    n = float(n)
    for u in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024: return f"{n:.1f} {u}" if u != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} PB"

def fmt_num(n):
    n = float(n or 0); sign = "-" if n < 0 else ""; n = abs(n)
    if n >= 1e12: return f"{sign}{n/1e12:.2f}T"
    if n >= 1e9:  return f"{sign}{n/1e9:.2f}B"
    if n >= 1e6:  return f"{sign}{n/1e6:.2f}M"
    if n >= 1e3:  return f"{sign}{n/1e3:.1f}K"
    return f"{sign}{int(n)}"

def fmt_when(ts):
    try: return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
    except Exception: return ""

def html_escape(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&#39;"))

@ttl_cache(120)
def dir_size(p_str):
    p = Path(p_str)
    if not p.exists(): return 0
    if p.is_file(): return p.stat().st_size
    total = 0
    try:
        for root, _, files in os.walk(p, followlinks=False):
            for f in files:
                try: total += os.lstat(os.path.join(root, f)).st_size
                except OSError: pass
    except OSError: pass
    return total

@ttl_cache(120)
def latest_mtime(p_str):
    p = Path(p_str)
    if not p.exists(): return 0
    if p.is_file(): return p.stat().st_mtime
    latest = 0
    try:
        for root, _, files in os.walk(p, followlinks=False):
            for f in files:
                try:
                    m = os.lstat(os.path.join(root, f)).st_mtime
                    if m > latest: latest = m
                except OSError: pass
    except OSError: pass
    return latest

# ---------- desktop actions ----------
def open_in_finder(path):
    try: subprocess.run(["open", path], check=False); return True
    except Exception: return False

def open_in_terminal(path):
    try:
        target = path if os.path.isdir(path) else os.path.dirname(path)
        subprocess.run(["open", "-a", "Terminal", target], check=False); return True
    except Exception: return False

def terminal_run(cmd, cwd=None):
    """Open Terminal and run cmd via a temp .command file + `open`.
    This does NOT require Automation (Apple Events) permission, unlike
    `osascript ... do script`, which macOS blocks by default (error -1743)."""
    workdir = cwd or os.getcwd()
    try:
        fd, path = tempfile.mkstemp(prefix="my-claude-", suffix=".command")
        with os.fdopen(fd, "w") as f:
            f.write("#!/bin/bash\ncd " + json.dumps(workdir) + "\n" + cmd + "\n")
        os.chmod(path, 0o755)
        rc = subprocess.run(["open", path], check=False).returncode
        return rc == 0
    except Exception:
        return False

def start_claude_in_project(project_path, resume_id=None):
    cmd = "claude" + (f" --resume {resume_id}" if resume_id else "")
    return terminal_run(cmd, cwd=project_path)

def open_file_default(path):
    try:
        if shutil.which("code"): subprocess.run(["code", path], check=False)
        else: subprocess.run(["open", "-e", path], check=False)
        return True
    except Exception: return False

def reveal(path):
    try: subprocess.run(["open", "-R", path], check=False); return True
    except Exception: return False

def pbcopy(text):
    try:
        p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE); p.communicate(text.encode()); return True
    except Exception: return False

def editor_name(): return "VSCode" if shutil.which("code") else "TextEdit"

# ---------- parsing ----------
def redact_secrets(obj):
    SECRETY = re.compile(r"(token|key|secret|password|pass|auth|bearer|cred)", re.I)
    if isinstance(obj, dict):
        return {k: ("<redacted>" if SECRETY.search(k) and isinstance(v, str) else redact_secrets(v)) for k, v in obj.items()}
    if isinstance(obj, list): return [redact_secrets(x) for x in obj]
    return obj

def parse_skill_meta(skill_dir):
    md = Path(skill_dir) / "SKILL.md"
    if not md.exists(): return {"description": "", "body": "", "raw": ""}
    try:
        text = md.read_text(errors="ignore")
        m = re.search(r"^---\s*\n(.*?)\n---\s*\n?(.*)", text, re.S | re.M)
        if not m: return {"description": "", "body": text, "raw": text}
        fm, body = m.group(1), m.group(2)
        d = re.search(r"^description:\s*(.+?)$", fm, re.M)
        return {"description": (d.group(1).strip().strip('"').strip("'") if d else "")[:500], "body": body, "raw": text}
    except Exception:
        return {"description": "", "body": "", "raw": ""}

@ttl_cache(300)
def parse_transcript_usage(jsonl_path):
    records = []
    try:
        with open(jsonl_path, "r", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                try: obj = json.loads(line)
                except Exception: continue
                msg = obj.get("message") or {}
                usage = msg.get("usage") if isinstance(msg, dict) else None
                if not usage: continue
                model = msg.get("model") or obj.get("model") or ""
                ts = obj.get("timestamp") or obj.get("ts") or ""
                records.append({"ts": ts, "model": model,
                                "input_tokens": int(usage.get("input_tokens") or 0),
                                "output_tokens": int(usage.get("output_tokens") or 0),
                                "cache_creation": int(usage.get("cache_creation_input_tokens") or 0),
                                "cache_read": int(usage.get("cache_read_input_tokens") or 0)})
    except Exception: pass
    return records

PRICING = {
    "opus":   {"input": 15.00, "output": 75.00, "cache_write": 18.75, "cache_read": 1.50},
    "sonnet": {"input":  3.00, "output": 15.00, "cache_write":  3.75, "cache_read": 0.30},
    "haiku":  {"input":  1.00, "output":  5.00, "cache_write":  1.25, "cache_read": 0.10},
}
def model_family(model_name):
    # PRICING TIER only (opus/sonnet/haiku). fable + others fall back to sonnet-tier for the cost ESTIMATE
    # (we don't have a verified fable list price; disclosed on the Usage page). Display uses model_label().
    n = (model_name or "").lower()
    if "opus" in n: return "opus"
    if "haiku" in n: return "haiku"
    return "sonnet"
def model_label(model_name):
    # version-aware DISPLAY label so opus versions split out and fable/others show as themselves
    # e.g. claude-opus-4-8 -> "opus 4.8", claude-fable-5 -> "fable 5", claude-haiku-4-5-2025.. -> "haiku 4.5"
    n = (model_name or "").lower()
    fam = next((f for f in ("opus", "sonnet", "haiku", "fable") if f in n), None)
    if not fam:
        return (model_name or "unknown").replace("claude-", "").replace("<", "").replace(">", "").replace("-", " ").strip() or "unknown"
    nums = []
    for p in n.split(fam, 1)[1].replace("_", "-").split("-"):
        if p == "": continue
        if p.isdigit() and len(p) <= 2: nums.append(p)
        else: break
    return (fam + " " + ".".join(nums[:2])) if nums else fam
def label_color(label):
    return FAMILY_COLOR.get((label or "").split(" ")[0], "#8a8a8a")
def cost_for(model_name, in_tok, out_tok, cw_tok, cr_tok):
    p = PRICING[model_family(model_name)]
    return (in_tok*p["input"] + out_tok*p["output"] + cw_tok*p["cache_write"] + cr_tok*p["cache_read"]) / 1_000_000

@ttl_cache(300)
def aggregate_usage():
    rows = []
    pdir = CLAUDE / "projects"
    if not pdir.exists(): return pd.DataFrame()
    for proj in pdir.iterdir():
        if not proj.is_dir(): continue
        decoded = proj.name.replace("-", "/") if proj.name.startswith("-") else proj.name
        for jf in proj.glob("*.jsonl"):
            sid = jf.name.split(".")[0]
            for r in parse_transcript_usage(str(jf)):
                r2 = dict(r); r2["project"] = decoded; r2["session"] = sid
                r2["family"] = model_family(r["model"])  # pricing tier
                r2["label"] = model_label(r["model"])    # version-aware display
                r2["cost"] = cost_for(r["model"], r["input_tokens"], r["output_tokens"], r["cache_creation"], r["cache_read"])
                try: r2["date"] = pd.to_datetime(r["ts"]).date()
                except Exception: r2["date"] = None
                rows.append(r2)
    return pd.DataFrame(rows) if rows else pd.DataFrame()

@ttl_cache(600)
def transcript_label(jsonl_path):
    try:
        with open(jsonl_path, "r", errors="ignore") as f:
            for line in f:
                if not line.strip(): continue
                try: obj = json.loads(line)
                except Exception: continue
                msg = obj.get("message") or obj
                role = obj.get("type") or msg.get("role") or ""
                if role not in ("user", "human"): continue
                content = msg.get("content") if isinstance(msg, dict) else None
                text = ""
                if isinstance(content, str): text = content
                elif isinstance(content, list):
                    for c in content:
                        if isinstance(c, dict) and c.get("type") == "text": text = c.get("text", ""); break
                text = re.sub(r"\s+", " ", text).strip()
                if text and not text.startswith("<"):
                    return text[:80] + ("…" if len(text) > 80 else "")
    except Exception: pass
    return ""

def parse_transcript_messages(jsonl_path, max_messages=500):
    messages = []
    try:
        with open(jsonl_path, "r", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                try: entry = json.loads(line)
                except json.JSONDecodeError: continue
                if entry.get("type", "") not in ("user", "assistant"): continue
                msg = entry.get("message", {}); role = msg.get("role", entry.get("type"))
                content = msg.get("content", ""); ts = entry.get("timestamp")
                if isinstance(content, str): text = content.strip()
                elif isinstance(content, list):
                    parts = []
                    for block in content:
                        if isinstance(block, dict):
                            bt = block.get("type", "")
                            if bt == "text": parts.append(block.get("text", ""))
                            elif bt == "tool_use": parts.append(f"`[Tool: {block.get('name','unknown')}]`")
                        elif isinstance(block, str): parts.append(block)
                    text = "\n".join(parts).strip()
                else: text = ""
                if not text: continue
                non_tool = [l for l in text.split("\n") if l.strip() and not l.strip().startswith("`[Tool:")]
                if not non_tool: continue
                messages.append({"role": role, "text": text, "ts": ts})
                if len(messages) >= max_messages: break
    except Exception: pass
    return messages

# ---------- config ----------
DEFAULT_CONFIG = {"github_owner": "", "default_visibility": "private", "repo_prefix": "claude-skill-",
                  "commit_message_template": "Update {skill} skill", "pushed_skills": {}}
def load_config_dict():
    if CONFIG_PATH.exists():
        try: return {**DEFAULT_CONFIG, **json.loads(CONFIG_PATH.read_text())}
        except Exception: pass
    return dict(DEFAULT_CONFIG)
def save_config(cfg): CONFIG_PATH.write_text(json.dumps(cfg, indent=2))

# ---------- gh ----------
def run_cmd(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return p.returncode, p.stdout.strip(), p.stderr.strip()

def _gh_status_fresh():
    if not shutil.which("gh"):
        return {"logged_in": False, "user": "", "raw": "", "gh_present": False, "host": ""}
    rc, out, err = run_cmd(["gh", "auth", "status"])
    text = (out + "\n" + err).strip()
    logged_in = rc == 0 and "Logged in to" in text
    user = host = ""
    m = re.search(r"account ([A-Za-z0-9_-]+)", text) or re.search(r"as ([A-Za-z0-9_-]+)", text)
    if m: user = m.group(1)
    h = re.search(r"Logged in to ([A-Za-z0-9.\-]+)", text)
    if h: host = h.group(1)
    return {"logged_in": logged_in, "user": user, "raw": text, "gh_present": True, "host": host}

@ttl_cache(60)
def gh_auth_status():
    return _gh_status_fresh()

def gh_repo_exists(owner, repo):
    rc, _, _ = run_cmd(["gh", "repo", "view", f"{owner}/{repo}"]); return rc == 0

# ---------- GitHub device-code login (no Terminal, no stored tokens) ----------
# State machine: idle -> pending (code shown, gh polling) -> done (logged in) | closed (gh exited/expired)
_ANSI = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\][0-9;]*")
_GH_URL = "https://github.com/login/device"
_gh_login = {"pid": None, "fd": None, "code": None, "url": _GH_URL, "state": "idle", "started": 0.0}
_gh_lock = threading.Lock()

def _proc_alive(pid):
    if not pid: return False
    try: os.kill(pid, 0); return True
    except OSError: return False

def _gh_release(kill=True):
    """Release pty/process resources. Does NOT change state (caller owns that)."""
    if _gh_login["fd"] is not None:
        try: os.close(_gh_login["fd"])
        except OSError: pass
        _gh_login["fd"] = None
    if kill and _gh_login["pid"]:
        try: os.kill(_gh_login["pid"], signal.SIGTERM)
        except OSError: pass
    if _gh_login["pid"]:
        try: os.waitpid(_gh_login["pid"], os.WNOHANG)
        except OSError: pass
    _gh_login["pid"] = None

def _kill_stray_gh_logins():
    """Belt-and-suspenders: reap any orphaned `gh auth login` processes this app spawned."""
    try:
        out = subprocess.run(["pgrep", "-f", "gh auth login"], capture_output=True, text=True).stdout
        for p in out.split():
            try: os.kill(int(p), signal.SIGTERM)
            except (OSError, ValueError): pass
    except Exception: pass

def _gh_drain(fd, pid):
    """Keep the pty alive so gh can poll GitHub: auto-accept follow-up prompts, mark state on exit."""
    buf = ""
    end = time.time() + 900
    while time.time() < end:
        try: r, _, _ = select.select([fd], [], [], 1.0)
        except (OSError, ValueError): break
        if fd in r:
            try: data = os.read(fd, 2048)
            except OSError: break
            if not data: break
            buf = (buf + _ANSI.sub("", data.decode(errors="replace")))[-2000:]
            if re.search(r"\?\s.*\((Y/n|y/N)\)", buf) or buf.rstrip().endswith("?"):
                try: os.write(fd, b"\n")
                except OSError: break
                buf = ""
        if not _proc_alive(pid): break
    with _gh_lock:
        if _gh_login["pid"] == pid:
            logged_in = _gh_status_fresh()["logged_in"]
            _gh_release(kill=True)
            _gh_login["state"] = "done" if logged_in else "closed"

def gh_login_start():
    with _gh_lock:
        if not shutil.which("gh"):
            return {"ok": False, "error": "gh CLI not installed. Install with: brew install gh"}
        # reuse a still-live pending code (dedupes rapid double-clicks) unless it's old
        if (_gh_login["state"] == "pending" and _gh_login["code"] and _proc_alive(_gh_login["pid"])
                and (time.time() - _gh_login["started"]) < 600):
            return {"ok": True, "code": _gh_login["code"], "url": _GH_URL}
        _gh_release(kill=True)
        _kill_stray_gh_logins()
        _gh_login.update({"state": "idle", "code": None})
        pid, fd = pty.fork()
        if pid == 0:
            os.environ["CLICOLOR"] = "0"; os.environ["NO_COLOR"] = "1"
            os.execvp("gh", ["gh", "auth", "login", "-h", "github.com", "-p", "https", "-w"])
            os._exit(127)
        _gh_login.update({"pid": pid, "fd": fd, "code": None, "url": _GH_URL, "state": "starting", "started": time.time()})
    # read output until the one-time code appears
    buf = ""; code = None; deadline = time.time() + 25
    while time.time() < deadline and code is None:
        try: r, _, _ = select.select([fd], [], [], 0.5)
        except (OSError, ValueError): break
        if fd in r:
            try: data = os.read(fd, 2048)
            except OSError: break
            if not data: break
            buf += _ANSI.sub("", data.decode(errors="replace"))
            m = re.search(r"one-time code:\s*([A-Z0-9]{4}-[A-Z0-9]{4})", buf)
            if m: code = m.group(1)
    if not code:
        with _gh_lock: _gh_release(kill=True); _gh_login["state"] = "closed"
        return {"ok": False, "error": "Could not get a device code from gh. Run `gh auth login` in a terminal instead."}
    with _gh_lock: _gh_login["code"] = code; _gh_login["state"] = "pending"
    # Return the code first so the app can show it; gh opens the browser a few seconds
    # LATER (see _gh_after_code) so the user has time to read/copy the code.
    threading.Thread(target=_gh_after_code, args=(fd, pid), daemon=True).start()
    return {"ok": True, "code": code, "url": _GH_URL}

def _gh_after_code(fd, pid):
    time.sleep(3)  # let the user read/copy the code before gh opens the browser
    try: os.write(fd, b"\n")  # press Enter so gh opens the browser and starts polling GitHub
    except OSError: pass
    _gh_drain(fd, pid)

def gh_login_status():
    st = _gh_status_fresh()
    if st["logged_in"]:
        with _gh_lock: _gh_login["state"] = "done"
        return {"logged_in": True, "user": st["user"], "host": st["host"], "state": "done"}
    with _gh_lock:
        state = _gh_login["state"]
        # a "pending" login whose gh process has died = expired/closed
        if state == "pending" and not _proc_alive(_gh_login["pid"]):
            _gh_login["state"] = state = "closed"
        elif state == "pending" and (time.time() - _gh_login["started"]) > 890:
            _gh_release(kill=True); _gh_login["state"] = state = "closed"
    return {"logged_in": False, "user": "", "host": "", "state": state}

SECRET_PATTERNS = [
    ("Private key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b|\bgithub_pat_[A-Za-z0-9_]{20,}\b")),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("OpenAI/Anthropic key", re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{20,}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("Assigned secret", re.compile(r"(?i)\b(api[_-]?key|secret|token|password|passwd|access[_-]?key|client[_-]?secret|auth[_-]?token)\b\s*[:=]\s*['\"][^'\"\s]{8,}['\"]")),
]
SKIP_SECRET_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".pdf", ".woff", ".woff2", ".ico", ".mp4", ".mov", ".pyc", ".lock"}
def scan_skill_secrets(skill_path, max_bytes=300_000):
    """Best-effort scan of a skill's files for likely credentials, before pushing to GitHub."""
    findings = []; base = Path(skill_path)
    if not base.exists(): return findings
    for p in sorted(base.rglob("*")):
        if not p.is_file() or p.suffix.lower() in SKIP_SECRET_EXT: continue
        rel = str(p.relative_to(base))
        if "/.git/" in ("/" + rel): continue
        if p.name == ".env" or p.name.endswith(".env"):
            findings.append({"file": rel, "line": 0, "type": "Env file", "snippet": ".env file (will be published)"}); continue
        try:
            if p.stat().st_size > max_bytes: continue
            text = p.read_text(errors="ignore")
        except Exception: continue
        for i, line in enumerate(text.splitlines(), 1):
            low = line.lower()
            if "<redacted>" in low or "example" in low or "your-" in low or "xxxx" in low: continue
            for label, rx in SECRET_PATTERNS:
                if rx.search(line):
                    findings.append({"file": rel, "line": i, "type": label, "snippet": line.strip()[:120]}); break
            if len(findings) >= 40: return findings
    return findings

def push_skill_to_github(skill_path, owner, repo, visibility):
    log = []; skill_path = Path(skill_path)
    if not skill_path.exists(): return False, "", f"Skill path not found: {skill_path}"
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td) / repo; stage.mkdir()
        ignore = shutil.ignore_patterns(".venv", "__pycache__", ".DS_Store", "*.pyc", ".git")
        for entry in skill_path.iterdir():
            dst = stage / entry.name
            try:
                if entry.is_dir(): shutil.copytree(entry, dst, ignore=ignore, dirs_exist_ok=True)
                else: shutil.copy2(entry, dst)
            except Exception as e: log.append(f"skip {entry.name}: {e}")
        readme = stage / "README.md"
        if not readme.exists():
            meta = parse_skill_meta(skill_path)
            readme.write_text(f"# {skill_path.name}\n\n{meta['description']}\n\n---\n\n{meta['body']}")
        for cmd in [["git", "init", "-b", "main"], ["git", "add", "-A"], ["git", "commit", "-m", f"Initial commit of {skill_path.name} skill"]]:
            rc, out, err = run_cmd(cmd, cwd=str(stage)); log.append(f"$ {' '.join(cmd)}\n{out}\n{err}")
            if rc != 0 and "nothing to commit" not in (out + err): return False, "", "\n".join(log)
        full = f"{owner}/{repo}"
        if gh_repo_exists(owner, repo):
            log.append(f"Repo {full} exists, pushing updates.")
            run_cmd(["git", "remote", "add", "origin", f"https://github.com/{full}.git"], cwd=str(stage))
            rc, out, err = run_cmd(["git", "push", "-u", "--force", "origin", "main"], cwd=str(stage)); log.append(out + err)
            if rc != 0: return False, "", "\n".join(log)
        else:
            cmd = ["gh", "repo", "create", full, f"--{visibility}", "--source", str(stage),
                   "--remote", "origin", "--push", "--description", f"Claude skill: {skill_path.name}"]
            rc, out, err = run_cmd(cmd); log.append(out + err)
            if rc != 0: return False, "", "\n".join(log)
        return True, f"https://github.com/{full}", "\n".join(log)

def install_skill_from_url(url, custom_name=None):
    log = []
    m = re.match(r"https?://github\.com/([^/]+)/([^/.]+)(?:\.git)?/?$", url.strip())
    if not m: return False, "", "URL must be of the form https://github.com/owner/repo"
    owner, repo = m.group(1), m.group(2)
    name = re.sub(r"[^A-Za-z0-9_.-]", "-", (custom_name or repo).strip())
    target = CLAUDE / "skills" / name
    if target.exists(): return False, name, f"Already exists: {target}"
    rc, out, err = run_cmd(["git", "clone", "--depth", "1", url.strip(), str(target)]); log.append(out + err)
    if rc != 0: return False, name, "\n".join(log)
    if not (target / "SKILL.md").exists():
        log.append("Warning: no SKILL.md in repo root. Claude won't recognize it as a skill until SKILL.md is added.")
    return True, name, "\n".join(log)

def mcp_check(name, cfg):
    if not isinstance(cfg, dict): return ("unknown", "config not a dict")
    if "url" in cfg:
        try:
            import urllib.request
            req = urllib.request.Request(cfg["url"], method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp: return ("ok", f"HTTP {resp.status}")
        except Exception as e: return ("fail", f"{type(e).__name__}: {str(e)[:80]}")
    cmd = cfg.get("command")
    if cmd:
        if shutil.which(cmd) or os.path.exists(cmd): return ("ok", f"command found: {cmd}")
        return ("fail", f"command not found: {cmd}")
    return ("unknown", "no url or command")

def make_skill_zip(skill_path):
    skill_path = Path(skill_path); buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(skill_path):
            dirs[:] = [d for d in dirs if d not in (".venv", "__pycache__", ".git")]
            for f in files:
                if f == ".DS_Store" or f.endswith(".pyc"): continue
                full = Path(root) / f
                zf.write(full, arcname=str(full.relative_to(skill_path.parent)))
    buf.seek(0); return buf.read()

# ---------- collectors ----------
@ttl_cache(120)
def get_plugin_skill_names():
    names = set(); pdir = CLAUDE / "plugins"
    if not pdir.exists(): return names
    for root, dirs, files in os.walk(pdir, followlinks=False):
        if "SKILL.md" in files: names.add(Path(root).name)
    return names

_SKILL_CATS = [
    ("Evals & Benchmarks", ["eval", "benchmark", "scorecard", "dataset", "ab-test", "experiment", "regression-eval"]),
    ("Security", ["security", "vuln", "pentest", "pen-test", "threat", "exploit", "owasp", "secret", "jwt", "xss", "sql-injection", "injection", "red-team", "fuzz", "sast", "csp", "cors", "zap", "burp", "malware", "auth-", "oauth", "zeroize", "yara", "seatbelt", "supply-chain"]),
    ("Testing & QA", ["test", "qa", "playwright", "cypress", "selenium", "e2e", "coverage", "bdd", "tdd", "mutation", "flak", "regression", "assert", "mock", "fixture", "appium", "espresso", "junit", "pytest", "jest", "naodeng", "qe-", "qcsd", "vitest", "cucumber"]),
    ("Database & Data", ["sql", "database", "postgres", "mongo", "redis", "data-quality", "migration", "schema", "orm", "drizzle", "prisma", "elasticsearch", "data-pipeline", "snowflake", "spark", "statistic", "analyst", "analytics", "pandas"]),
    ("DevOps & Infra", ["kubernetes", "k8s", "docker", "terraform", "helm", "cloud", "aws", "azure", "gcp", "ci-", "cicd", "deploy", "observ", "slo", "sre", "runbook", "incident", "infra", "devops", "monitoring", "canary", "serverless", "operator"]),
    ("Frontend & UI", ["react", "vue", "angular", "svelte", "next", "frontend", "css", "design-system", "accessibility", "a11y", "responsive", "visual", "screenshot", "dark-mode", "storybook", "shadcn", "theme", "ux", "layout", "design"]),
    ("AI, LLM & Agents", ["llm", "agent", "mcp", "prompt", "rag", "neural", "swarm", "fine-tun", "reasoningbank", "flow-nexus", "ml-"]),
    ("Skill & Workflow Authoring", ["skill", "workflow", "subagent", "sparc"]),
    ("Docs & Reports", ["report", "markdown", "md-", "slides", "marp", "pdf", "xlsx", "pptx", "docx", "changelog", "technical-writing", "doc-", "documenter"]),
    ("Productivity & Process", ["plan", "brainstorm", "review", "git", "github", "handoff", "memory", "remember", "resume", "eod", "eos", "news", "daily", "organize", "task", "scrum", "jira", "confluence"]),
]
_EXACT = {"orm", "ml", "ux", "ci", "eval"}
def categorize_skill(name, desc):
    def hit(text, kws):
        toks = re.findall(r"[a-z0-9]+", text)
        for kw in kws:
            if "-" in kw or " " in kw:
                if kw in text: return True
            elif kw in _EXACT:
                if any(t == kw for t in toks): return True
            elif any(t == kw or t.startswith(kw) for t in toks): return True
        return False
    nm = name.lower()
    for label, kws in _SKILL_CATS:
        if hit(nm, kws): return label
    hay = (name + " " + desc).lower()
    for label, kws in _SKILL_CATS:
        if hit(hay, kws): return label
    return "Other"

@ttl_cache(120)
def load_skills():
    sk = CLAUDE / "skills"; plugin_names = get_plugin_skill_names(); rows = []
    if not sk.exists(): return []
    for p in sorted(sk.iterdir()):
        if not p.is_dir(): continue
        meta = parse_skill_meta(p)
        rows.append({"name": p.name, "description": meta["description"], "size": dir_size(str(p)),
                     "size_human": fmt_size(dir_size(str(p))), "path": str(p), "mtime": latest_mtime(str(p)),
                     "cat": categorize_skill(p.name, meta["description"]),
                     "source": "plugin" if p.name in plugin_names else "local"})
    return rows

@ttl_cache(120)
def load_memory():
    """Read the persistent memory files (~/.claude/projects/*/memory/*.md)."""
    out = []; base = CLAUDE / "projects"; home_short = HOME.name
    if base.exists():
        for md in base.glob("*/memory/*.md"):
            try: txt = md.read_text(errors="ignore")
            except OSError: continue
            slug = md.parent.parent.name
            project = slug.replace("-", "/") if slug.startswith("-") else slug
            proj_short = project.split("/")[-1] or project
            m = re.search(r"^---\s*\n(.*?)\n---\s*\n?(.*)", txt, re.S)
            name = md.stem; desc = ""
            if m:
                nn = re.search(r"^name:\s*(.+)$", m.group(1), re.M); dd = re.search(r"^description:\s*(.+)$", m.group(1), re.M)
                if nn: name = nn.group(1).strip().strip('"').strip("'")
                if dd: desc = dd.group(1).strip().strip('"').strip("'")
            if not desc:
                for ln in (m.group(2) if m else txt).splitlines():
                    ln = ln.strip()
                    if ln and not ln.startswith(("#", "-", "*", "|", ">", "`")): desc = ln[:160]; break
            is_index = md.name.upper() == "MEMORY.MD"
            title = f"{proj_short} · index" if is_index else name
            out.append({"name": name, "title": title, "desc": desc[:200], "path": str(md), "file": md.name,
                        "project": proj_short, "is_index": is_index, "is_home": proj_short == home_short,
                        "size": md.stat().st_size})
    out.sort(key=lambda x: (not x["is_home"], not x["is_index"], x["project"].lower(), x["name"].lower()))
    return out

HOOK_DESC = {
    "sessionstart": "Runs when a Claude Code session starts.",
    "sessionend": "Runs when a session ends.",
    "userpromptsubmit": "Runs each time you submit a prompt.",
    "pretooluse": "Runs before a tool executes; can block or change it.",
    "posttooluse": "Runs after a tool finishes.",
    "precompact": "Runs before the conversation context is compacted.",
    "notification": "Runs on notifications, e.g. when Claude needs permission.",
    "stop": "Runs when the main agent finishes responding.",
    "subagentstop": "Runs when a subagent finishes.",
}
SETTINGS_DESC = {
    "effortlevel": "Default reasoning effort for the model.",
    "enabledplugins": "Plugins currently switched on.",
    "extraknownmarketplaces": "Extra plugin marketplaces Claude Code trusts.",
    "hooks": "Shell commands wired to lifecycle events.",
    "permissions": "Allow / ask / deny rules for tools.",
    "skipautopermissionprompt": "Skip the automatic permission prompt.",
    "skipdangerousmodepermissionprompt": "Skip the dangerous-mode confirmation prompt.",
    "tui": "Terminal UI preferences.",
    "model": "Default model selection.",
    "theme": "Colour theme preference.",
    "statusline": "Custom status-line command.",
    "env": "Environment variables passed to tools.",
    "includecoauthoredby": "Adds a Co-Authored-By line to git commits.",
    "outputstyle": "Response output style.",
    "autoupdaterstatus": "Auto-update behaviour for the CLI.",
    "apikeyhelper": "Command that supplies the API key.",
}
def _cfg_desc(table, key):
    return table.get(re.sub(r"[^a-z0-9]", "", key.lower()), "")

@ttl_cache(120)
def load_config_detail():
    """settings.json permissions + hooks, and CLAUDE.md content."""
    settings = {}
    sp = CLAUDE / "settings.json"
    if sp.exists():
        try: settings = json.loads(sp.read_text())
        except Exception: settings = {}
    perms = settings.get("permissions") or {}
    hooks = settings.get("hooks") or {}
    hk = sorted(hooks.keys()) if isinstance(hooks, dict) else []
    hook_events = [{"name": h, "desc": _cfg_desc(HOOK_DESC, h)} for h in hk]
    settings_keys = [{"name": k, "desc": _cfg_desc(SETTINGS_DESC, k)} for k in sorted(settings.keys())]
    claude_md = ""
    cm = CLAUDE / "CLAUDE.md"
    if cm.exists():
        try: claude_md = cm.read_text(errors="ignore")
        except OSError: pass
    return {"allow": perms.get("allow") or [], "deny": perms.get("deny") or [], "ask": perms.get("ask") or [],
            "hook_events": hook_events, "claude_md": claude_md, "settings_keys": settings_keys}

@ttl_cache(120)
def load_connectors():
    """All MCP servers from every config source: global (settings.json / .claude.json)
    and per-project (.claude.json projects[*].mcpServers). Scope shows where it applies."""
    out = []
    for cfg in [CLAUDE / "settings.json", HOME / ".claude.json"]:
        if not cfg.exists(): continue
        try: data = json.loads(cfg.read_text())
        except Exception: continue
        for k, v in (data.get("mcpServers") or {}).items():
            out.append({"name": k, "source": cfg.name, "scope": "global", "config": redact_secrets(v)})
        projs = data.get("projects") if isinstance(data.get("projects"), dict) else {}
        for ppath, pv in projs.items():
            for k, v in ((pv or {}).get("mcpServers") or {}).items():
                proj = ppath.replace(str(HOME), "~")
                out.append({"name": k, "source": cfg.name, "scope": proj, "config": redact_secrets(v)})
    return out

@ttl_cache(120)
def load_plugins():
    out = []; pdir = CLAUDE / "plugins"
    if not pdir.exists(): return out
    inst = pdir / "installed_plugins.json"
    if inst.exists():
        try:
            data = json.loads(inst.read_text()); plugins = data.get("plugins") or data
            if isinstance(plugins, dict):
                for k, v in plugins.items(): out.append({"name": k, "info": v})
            elif isinstance(plugins, list):
                for v in plugins: out.append({"name": v.get("name", "?"), "info": v})
        except Exception: pass
    mk = pdir / "marketplaces"
    if mk.exists():
        for m in mk.iterdir():
            if m.is_dir(): out.append({"name": f"marketplace/{m.name}", "info": {"path": str(m), "size": fmt_size(dir_size(str(m)))}})
    return out

@ttl_cache(120)
def load_projects():
    pdir = CLAUDE / "projects"; rows = []
    if not pdir.exists(): return []
    for p in sorted(pdir.iterdir()):
        if not p.is_dir(): continue
        slug = p.name; decoded = slug.replace("-", "/") if slug.startswith("-") else slug
        files = list(p.glob("*.jsonl"))
        sz = dir_size(str(p))
        rows.append({"project": decoded, "slug": slug, "transcripts": len(files), "size": sz,
                     "size_human": fmt_size(sz), "path": str(p),
                     "last_active": max((f.stat().st_mtime for f in files), default=0),
                     "exists": Path(decoded).exists()})
    rows.sort(key=lambda r: r["last_active"], reverse=True)
    return rows

def list_project_sessions(project_storage_path):
    p = Path(project_storage_path)
    if not p.exists(): return []
    out = []
    for f in p.glob("*.jsonl"):
        s = f.stat(); out.append({"name": f.name, "size": s.st_size, "mtime": s.st_mtime, "path": str(f)})
    return sorted(out, key=lambda x: -x["mtime"])

@ttl_cache(120)
def load_config_files():
    rows = []
    for f in ["settings.json", "settings.local.json", "CLAUDE.md", "policy-limits.json", "stats-cache.json", "mcp-needs-auth-cache.json", ".last-cleanup"]:
        p = CLAUDE / f
        if p.exists(): rows.append({"name": f, "size": dir_size(str(p)), "size_human": fmt_size(dir_size(str(p))), "path": str(p)})
    cdir = CLAUDE / "commands"
    if cdir.exists():
        for c in cdir.iterdir():
            rows.append({"name": f"commands/{c.name}", "size": dir_size(str(c)), "size_human": fmt_size(dir_size(str(c))), "path": str(c)})
    rows.sort(key=lambda r: r["size"], reverse=True)
    return rows

@ttl_cache(120)
def load_cache():
    rows = []
    for d in ["shell-snapshots", "paste-cache", "file-history", "image-cache", "session-env", "telemetry", "ide", "cache", "downloads", "debug", "backups", "todos"]:
        p = CLAUDE / d
        if p.exists():
            rows.append({"name": d, "items": len(list(p.iterdir())) if p.is_dir() else 0, "size": dir_size(str(p)), "size_human": fmt_size(dir_size(str(p))), "path": str(p)})
    h = CLAUDE / "history.jsonl"
    if h.exists(): rows.append({"name": "history.jsonl", "items": 0, "size": h.stat().st_size, "size_human": fmt_size(h.stat().st_size), "path": str(h)})
    rows.sort(key=lambda r: r["size"], reverse=True)
    return rows

@ttl_cache(120)
def load_tasks():
    rows = []
    for d in ["tasks", "plans"]:
        p = CLAUDE / d
        if p.exists(): rows.append({"name": d, "items": len(list(p.iterdir())), "size": dir_size(str(p)), "size_human": fmt_size(dir_size(str(p))), "path": str(p)})
    return rows

def ts_epoch(v):
    """Best-effort timestamp -> epoch seconds. Handles ISO strings and int/float."""
    if v is None: return 0
    if isinstance(v, (int, float)): return float(v if v < 1e12 else v / 1000)
    if isinstance(v, str):
        s = v.strip()
        if s.isdigit(): n = int(s); return float(n if n < 1e12 else n / 1000)
        try: return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
        except Exception: return 0
    return 0

# ---- persistent per-file scan cache (keyed by path + mtime + size), for fast cold loads ----
CACHE_FILE = SKILL_DIR / ".mc_cache.json"
_disk = None; _dirty = False
CMD_RE = re.compile(r"<command-name>/?([a-zA-Z0-9:_.-]{2,48})</command-name>")
# Claude Code built-in slash commands — excluded from skill-usage attribution so a built-in
# like /resume isn't miscounted as a same-named skill. (Skill tool_use invocations still count.)
BUILTIN_CMDS = {"add-dir", "agents", "bug", "clear", "compact", "config", "cost", "doctor", "exit",
                "export", "help", "hooks", "init", "login", "logout", "mcp", "memory", "model",
                "permissions", "pr-comments", "release-notes", "resume", "review", "status",
                "terminal-setup", "usage-credits", "vim", "effort", "fast", "context", "rewind"}

_CACHE_V = 2  # bump when _scan_meta output shape/logic changes, to invalidate the on-disk cache
def _disk_load():
    global _disk
    if _disk is None:
        try: _disk = json.loads(CACHE_FILE.read_text())
        except Exception: _disk = {}
        if _disk.get("_v") != _CACHE_V: _disk = {"_v": _CACHE_V}
    return _disk

def _disk_flush():
    global _dirty
    if _dirty:
        try: CACHE_FILE.write_text(json.dumps(_disk)); _dirty = False
        except Exception: pass

def _scan_meta(path):
    """One read per transcript: preview, timestamps, message count, and skill invocations."""
    first_user = ""; first_ts = last_ts = 0; n = 0; skills = []
    try:
        with open(path, "r", errors="ignore") as f:
            for raw in f:
                raw = raw.strip()
                if not raw: continue
                cmds = CMD_RE.findall(raw) if "<command-name>" in raw else []
                skill_tool = '"name":"Skill"' in raw
                try: e = json.loads(raw)
                except Exception: continue
                if e.get("type") not in ("user", "assistant"): continue
                t = ts_epoch(e.get("timestamp") or e.get("ts"))
                msg = e.get("message") or {}
                content = msg.get("content") if isinstance(msg, dict) else None
                for cm in cmds:
                    if cm.split(":")[-1] not in BUILTIN_CMDS: skills.append([cm, t])
                if skill_tool and isinstance(content, list):
                    for b in content:
                        if isinstance(b, dict) and b.get("type") == "tool_use" and b.get("name") == "Skill":
                            sk = (b.get("input") or {}).get("skill")
                            if sk: skills.append([sk, t])
                text = ""
                if isinstance(content, str): text = content
                elif isinstance(content, list):
                    for c in content:
                        if isinstance(c, dict) and c.get("type") == "text": text += c.get("text", "") + " "
                text = re.sub(r"\s+", " ", text).strip()
                if not text or text.startswith("<"): continue
                n += 1
                if t:
                    if not first_ts: first_ts = t
                    last_ts = t
                role = e.get("type") or (msg.get("role") if isinstance(msg, dict) else "")
                if role in ("user", "human") and not first_user: first_user = text[:120]
    except Exception: pass
    return {"preview": first_user or "(no preview)", "first_ts": first_ts, "last_ts": last_ts, "n": n, "skills": skills}

def _conv_meta(path):
    global _dirty
    d = _disk_load()
    try: st = os.stat(path)
    except OSError: return _scan_meta(path)
    c = d.get(path)
    if c and c.get("mt") == st.st_mtime and c.get("sz") == st.st_size:
        return c["v"]
    v = _scan_meta(path)
    d[path] = {"mt": st.st_mtime, "sz": st.st_size, "v": v}; _dirty = True
    return v

@ttl_cache(120)
def conversation_index(include_sub=False):
    """Top-level conversations by default. include_sub also walks nested sub-agent + workflow transcripts."""
    pdir = CLAUDE / "projects"; out = []
    if not pdir.exists(): return out
    for proj in pdir.iterdir():
        if not proj.is_dir(): continue
        decoded = proj.name.replace("-", "/") if proj.name.startswith("-") else proj.name
        globber = proj.rglob("*.jsonl") if include_sub else proj.glob("*.jsonl")
        for jf in globber:
            meta = _conv_meta(str(jf))
            if meta["n"] == 0: continue
            rel = jf.relative_to(proj)
            if len(rel.parts) == 1: kind = "conversation"
            elif "wf_" in str(rel): kind = "workflow"
            else: kind = "sub-agent"
            meta.update({"project": decoded, "session": jf.name.split(".")[0], "path": str(jf), "kind": kind})
            out.append(meta)
    out.sort(key=lambda r: r["last_ts"] or 0, reverse=True)
    _disk_flush()
    return out

@ttl_cache(120)
def skill_usage():
    """Accurate per-skill invocation counts + last-used, from transcript command-markers and Skill tool calls."""
    agg = {}
    for m in conversation_index():
        for name, ts in m.get("skills", []):
            key = str(name).split(":")[-1]
            a = agg.setdefault(key, {"count": 0, "last_ts": 0})
            a["count"] += 1
            if ts and ts > a["last_ts"]: a["last_ts"] = ts
    return agg

@ttl_cache(120)
def usage_stats():
    """Everything derived from per-turn usage: per-session cost, 7d/30d trends, cache savings, activity heatmap."""
    df = aggregate_usage()
    if df.empty: return {"empty": True, "by_session": {}}
    df = df.copy()
    df["billable"] = df["input_tokens"] + df["cache_creation"] + df["cache_read"] + df["output_tokens"]
    inp = df["family"].map(lambda f: PRICING[f]["input"]); crp = df["family"].map(lambda f: PRICING[f]["cache_read"])
    df["savings"] = df["cache_read"] * (inp - crp) / 1_000_000
    by_session = {s: {"cost": round(float(g["cost"].sum()), 4), "tokens": int(g["billable"].sum()), "turns": int(len(g))}
                  for s, g in df.groupby("session")}
    today = datetime.now().date()
    def win(a, b):
        sub = df[df["date"].apply(lambda d: bool(d) and a <= d < b)]
        return float(sub["cost"].sum()), int(sub["billable"].sum())
    c7, t7 = win(today - timedelta(days=7), today + timedelta(days=1))
    cp7, _ = win(today - timedelta(days=14), today - timedelta(days=7))
    c30, t30 = win(today - timedelta(days=30), today + timedelta(days=1))
    dd = df.dropna(subset=["date"])
    heat = [{"date": str(d), "v": int(v)} for d, v in dd.groupby("date").size().items()]
    daycost = dd.groupby("date")["cost"].sum()
    top_day = [str(daycost.idxmax()), round(float(daycost.max()), 2)] if len(daycost) else [None, 0]
    by_fam = {f: round(float(g["cost"].sum()), 2) for f, g in df.groupby("family")}
    return {"empty": False, "by_session": by_session, "cost7": c7, "tok7": t7, "cost_prev7": cp7,
            "cost30": c30, "tok30": t30, "savings": round(float(df["savings"].sum()), 2),
            "heat": heat, "top_day": top_day, "by_family": by_fam}

@ttl_cache(300)
def search_transcripts(needle, max_hits=200):
    needle_lc = needle.lower(); out = []; pdir = CLAUDE / "projects"
    if not pdir.exists(): return out
    for proj in pdir.iterdir():
        if not proj.is_dir(): continue
        decoded = proj.name.replace("-", "/") if proj.name.startswith("-") else proj.name
        for jf in proj.glob("*.jsonl"):
            try:
                with open(jf, "r", errors="ignore") as f:
                    for ln, line in enumerate(f, 1):
                        if needle_lc not in line.lower(): continue
                        try: obj = json.loads(line)
                        except Exception: snippet = line.strip()[:200]
                        else:
                            msg = obj.get("message") or obj
                            content = msg.get("content") if isinstance(msg, dict) else None
                            text = ""
                            if isinstance(content, str): text = content
                            elif isinstance(content, list):
                                for c in content:
                                    if isinstance(c, dict) and c.get("type") == "text": text += c.get("text", "") + " "
                            snippet = re.sub(r"\s+", " ", text or line)[:240]
                        out.append({"project": decoded, "session": jf.name.split(".")[0], "line": ln, "snippet": snippet, "path": str(jf)})
                        if len(out) >= max_hits: return out
            except Exception: continue
    return out

# ---------- shared context ----------
def theme_of(request): return request.cookies.get("theme", "light")

def base_ctx(request, page):
    auth = gh_auth_status(); cfg = load_config_dict()
    if auth["gh_present"] and auth["logged_in"]:
        chip = {"cls": "", "text": "GitHub: " + (auth["user"] or "connected")}
    elif auth["gh_present"]:
        chip = {"cls": "warn", "text": "GitHub not connected"}
    else:
        chip = {"cls": "warn", "text": "gh CLI not installed"}
    return {"request": request, "theme": theme_of(request), "claude_home": str(CLAUDE),
            "pages": PAGES, "page_slug": PAGE_SLUG, "active": page, "chip": chip,
            "eyebrow": EYEBROW.get(page, ""), "today": datetime.now().date().isoformat(),
            "updated": datetime.now().strftime("%H:%M"), "editor": editor_name()}

def render(request, template, page, **ctx):
    c = base_ctx(request, page); c.update(ctx)
    return templates.TemplateResponse(request, template, c)

# ---------- routes: pages ----------
@app.get("/", response_class=HTMLResponse)
def home(request: Request): return RedirectResponse("/p/overview")

@app.get("/toggle-theme")
def toggle_theme(request: Request, next: str = "/p/overview"):
    cur = theme_of(request); resp = RedirectResponse(next)
    resp.set_cookie("theme", "dark" if cur == "light" else "light", max_age=31536000)
    return resp

@app.get("/refresh")
def refresh(request: Request, next: str = "/p/overview"):
    clear_cache(); return RedirectResponse(next)

@app.get("/p/{slug}", response_class=HTMLResponse)
def page(request: Request, slug: str):
    if slug in REDIRECTS:
        qs = ("?" + str(request.url.query)) if request.url.query else ""
        return RedirectResponse(f"/p/{REDIRECTS[slug]}{qs}")
    name = SLUG_PAGE.get(slug)
    if not name: return RedirectResponse("/p/overview")
    if name == "Overview": return render_overview(request)
    if name == "Skills": return render_skills(request)
    if name == "MCP & Plugins": return render_extensions(request)
    if name == "Usage": return render_token(request)
    if name == "History": return render_history(request)
    if name == "System": return render_system(request)
    if name == "Help": return render_help(request)
    return RedirectResponse("/p/overview")

def _sizes():
    skills = load_skills(); projects = load_projects(); cfg = load_config_files(); cache = load_cache(); tasks = load_tasks()
    return {"Skills": sum(s["size"] for s in skills), "Sessions": sum(p["size"] for p in projects),
            "Config": sum(c["size"] for c in cfg), "Cache": sum(c["size"] for c in cache),
            "Tasks": sum(t["size"] for t in tasks), "Plugins": dir_size(str(CLAUDE / "plugins"))}

def render_overview(request):
    skills = load_skills(); projects = load_projects(); convs = conversation_index()
    connectors = load_connectors(); plugins = load_plugins(); cache = load_cache()
    n_mcp = len({c["name"] for c in connectors})
    sizes = _sizes(); total = sum(sizes.values()); now = datetime.now().timestamp()

    us = usage_stats()
    tokens30 = fmt_num(us["tok30"]) if not us.get("empty") else "—"
    cost30 = f"${us['cost30']:,.0f} · 30d" if not us.get("empty") else ""

    # this-week strip
    week = None
    if not us.get("empty"):
        delta = None
        if us["cost_prev7"] > 0:
            delta = (us["cost7"] - us["cost_prev7"]) / us["cost_prev7"] * 100
        proj_msgs = {}
        for c in convs: proj_msgs[c["project"]] = proj_msgs.get(c["project"], 0) + c["n"]
        busiest = max(proj_msgs.items(), key=lambda x: x[1]) if proj_msgs else (None, 0)
        week = {
            "cost7": f"${us['cost7']:,.2f}", "delta": (None if delta is None else round(delta)),
            "savings": f"${us['savings']:,.0f}",
            "busiest": (busiest[0].split('/')[-1] if busiest[0] else "—"), "busiest_n": busiest[1],
            "top_day": us["top_day"], "heat": json.dumps(us["heat"]),
        }

    kpis = [
        {"label": "Skills", "value": str(len(skills)), "sub": fmt_size(sizes["Skills"]), "href": "/p/skills"},
        {"label": "Conversations", "value": str(len(convs)), "sub": f"{sum(c['n'] for c in convs)} messages", "href": "/p/history"},
        {"label": "Tokens · 30d", "value": tokens30, "sub": cost30, "href": "/p/usage"},
        {"label": "On disk", "value": fmt_size(total), "sub": f"{n_mcp} MCP · {len(plugins)} plugins", "href": "/p/mcp-plugins"},
    ]
    recent_convs = [{"preview": c["preview"], "project": c["project"].split("/")[-1] or c["project"],
                     "when": fmt_when(c["last_ts"]) if c["last_ts"] else "—", "n": c["n"], "path": c["path"]}
                    for c in convs[:5]]
    recent_skills = sorted(skills, key=lambda s: -s["mtime"])[:5]

    # attention items (folded from Cleanup)
    stale = [p for p in projects if p["last_active"] and (now - p["last_active"]) / 86400 > 90]
    attention = []
    if stale:
        attention.append({"text": f"{len(stale)} stale projects (>90d inactive)",
                          "sub": f"{fmt_size(sum(p['size'] for p in stale))} reclaimable", "path": str(CLAUDE / "projects")})
    big = sorted(cache, key=lambda r: -r["size"])[:1]
    if big and big[0]["size"] > 50 * 1024 * 1024:
        attention.append({"text": f"Largest cache: {big[0]['name']}", "sub": big[0]["size_human"], "path": big[0]["path"]})

    bd = sorted([(k, v) for k, v in sizes.items() if v > 0], key=lambda x: x[1])
    chart = {"y": [k for k, v in bd], "x": [v for k, v in bd],
             "text": [fmt_size(v) for k, v in bd], "colors": [CAT_COLOR[k] for k, v in bd]}
    return render(request, "overview.html", "Overview", kpis=kpis, week=week, recent_convs=recent_convs,
                  recent_skills=recent_skills, attention=attention, chart=json.dumps(chart))

def _mcp_groups():
    """Group MCP registrations by server name (same server can be registered in several scopes)."""
    groups = {}
    for c in load_connectors():
        g = groups.setdefault(c["name"], {"name": c["name"], "scopes": [], "config": c["config"], "source": c["source"]})
        g["scopes"].append(c["scope"])
    return groups

def render_extensions(request):
    tab = request.query_params.get("tab", "mcp")
    q = request.query_params.get("q", "").lower()
    plugins = load_plugins(); groups = _mcp_groups()
    conn_shown = []
    for name, g in groups.items():
        if q and q not in name.lower(): continue
        has_global = "global" in g["scopes"]
        nproj = len([s for s in g["scopes"] if s != "global"])
        parts = (["global"] if has_global else []) + ([f"{nproj} project" + ("s" if nproj != 1 else "")] if nproj else [])
        conn_shown.append({"name": name, "scope_label": " · ".join(parts) or g["scopes"][0],
                           "scopes": g["scopes"], "source": g["source"], "key": name,
                           "config": json.dumps(g["config"], indent=2)})
    plug_shown = [{"name": p["name"], "info": json.dumps(p["info"], indent=2)}
                  for p in plugins if not q or q in p["name"].lower()]
    return render(request, "extensions.html", "MCP & Plugins", tab=tab, q=request.query_params.get("q", ""),
                  connectors=conn_shown, plugins=plug_shown, n_conn=len(groups), n_plug=len(plugins))

@app.get("/api/mcp-health")
def api_mcp_health():
    from concurrent.futures import ThreadPoolExecutor
    groups = list(_mcp_groups().values())
    def chk(g):
        status, detail = mcp_check(g["name"], g["config"])
        return {"key": g["name"], "status": status, "detail": detail}
    with ThreadPoolExecutor(max_workers=8) as ex:
        return list(ex.map(chk, groups))

def render_skills(request):
    cfg = load_config_dict(); auth = gh_auth_status(); skills = load_skills(); usage = skill_usage()
    q = request.query_params.get("q", ""); source = request.query_params.get("source", "All")
    sort = request.query_params.get("sort", "Name (A-Z)")
    # "Recent" is ON by default; the hidden recent=0 companion lets the toggle turn it off (take the last submitted value).
    _rv = request.query_params.getlist("recent"); recent = (_rv[-1] if _rv else "1")
    cats_sel = [c for c in request.query_params.getlist("cat") if c and c != "All"]
    try: page_n = int(request.query_params.get("page", "1"))
    except ValueError: page_n = 1
    now = datetime.now().timestamp(); recent_threshold = now - 7 * 24 * 3600
    pushed = cfg.get("pushed_skills") or {}
    for s in skills:
        u = usage.get(s["name"], {})
        s["uses"] = u.get("count", 0); s["last_used"] = u.get("last_ts", 0)
        s["is_recent"] = s["mtime"] > recent_threshold; s["pushed_url"] = pushed.get(s["name"], "")
        s["last_used_h"] = fmt_when(s["last_used"]).split(" ")[0] if s["last_used"] else "never"
    total = len(skills)
    cats = sorted({s["cat"] for s in skills})
    f = list(skills)
    if source == "Local": f = [s for s in f if s["source"] == "local"]
    elif source == "Plugin": f = [s for s in f if s["source"] == "plugin"]
    elif source == "Unused": f = [s for s in f if s["uses"] == 0]
    if cats_sel: f = [s for s in f if s["cat"] in cats_sel]
    if recent == "1": f = [s for s in f if s["mtime"] > recent_threshold]
    if q:
        ql = q.lower(); f = [s for s in f if ql in s["name"].lower() or ql in s["description"].lower()]
    if sort == "Name (A-Z)": f.sort(key=lambda s: s["name"].lower())
    elif sort == "Size (high to low)": f.sort(key=lambda s: -s["size"])
    elif sort == "Recently modified": f.sort(key=lambda s: -s["mtime"])
    elif sort == "Most used": f.sort(key=lambda s: (-s["uses"], s["name"].lower()))
    elif sort == "Last used": f.sort(key=lambda s: -s["last_used"])
    user_n = sum(1 for s in skills if s["source"] == "local"); plugin_n = total - user_n
    unused_n = sum(1 for s in skills if s["uses"] == 0)
    filt_size = fmt_size(sum(s["size"] for s in f))
    PAGE_SIZE = 30; total_pages = max(1, (len(f) + PAGE_SIZE - 1) // PAGE_SIZE)
    page_n = min(max(1, page_n), total_pages)
    chunk = f[(page_n-1)*PAGE_SIZE: page_n*PAGE_SIZE]
    # Push works as soon as GitHub is connected: the owner defaults to your connected account
    # (you can override it with a default owner/org in Settings, but you don't have to).
    can_push = auth["logged_in"] and bool(cfg.get("github_owner") or auth.get("user"))
    push_msg = ""
    if not can_push:
        push_msg = "Push disabled: connect your GitHub account in Settings."
    return render(request, "skills.html", "Skills", skills=chunk, count=len(f), total=total,
                  filt_size=filt_size, user_n=user_n, plugin_n=plugin_n, unused_n=unused_n, q=q, source=source, sort=sort,
                  recent=recent, cats_sel=cats_sel, cats=cats, page_n=page_n, total_pages=total_pages, can_push=can_push, push_msg=push_msg)

def render_connectors(request):
    items = load_connectors(); q = request.query_params.get("q", "").lower()
    health = request.query_params.get("health", "")
    shown = []
    for c in items:
        if q and q not in c["name"].lower(): continue
        rec = {"name": c["name"], "source": c["source"], "config": json.dumps(c["config"], indent=2)}
        if health:
            status, detail = mcp_check(c["name"], c["config"])
            rec["status"] = status; rec["detail"] = detail
            rec["status_color"] = {"ok": "#10b981", "fail": "#ef4444", "unknown": "#94a3b8"}[status]
        shown.append(rec)
    return render(request, "connectors.html", "MCP Connectors", items=shown, total=len(items), q=q, health=health)

def render_plugins(request):
    items = load_plugins(); q = request.query_params.get("q", "").lower()
    shown = [{"name": p["name"], "info": json.dumps(p["info"], indent=2)} for p in items if not q or q in p["name"].lower()]
    return render(request, "plugins.html", "Plugins", items=shown)

def render_sessions(request):
    projects = load_projects(); q = request.query_params.get("q", "").lower()
    f = projects if not q else [p for p in projects if q in p["project"].lower()]
    for p in f:
        p["last_active_h"] = fmt_when(p["last_active"]) if p["last_active"] else "—"
    filt_size = fmt_size(sum(p["size"] for p in f))
    return render(request, "sessions.html", "Sessions", projects=f, count=len(f), total=len(projects),
                  filt_size=filt_size, q=q)

@app.get("/p/sessions/{slug}/transcripts", response_class=HTMLResponse)
def session_transcripts(request: Request, slug: str):
    """Lazy-loaded transcript list for a project (HTML partial)."""
    storage = CLAUDE / "projects" / slug
    project_real = slug.replace("-", "/") if slug.startswith("-") else slug
    sessions = list_project_sessions(str(storage))
    for s in sessions:
        s["label"] = transcript_label(s["path"]) or "(unnamed conversation)"
        s["short_id"] = s["name"].split(".")[0][:8]; s["sid_full"] = s["name"].split(".")[0]
        s["when"] = fmt_when(s["mtime"]); s["size_h"] = fmt_size(s["size"])
    return templates.TemplateResponse(request, "_transcripts.html", {"request": request, "theme": theme_of(request),
        "sessions": sessions, "slug": slug, "project_real": project_real,
        "real_exists": Path(project_real).exists(), "editor": editor_name()})

def render_search(request):
    q = request.query_params.get("q", "").strip()
    ctx = {"q": q, "hits": None}
    if q:
        hits = search_transcripts(q); groups = {}
        for h in hits: groups.setdefault((h["project"], h["session"], h["path"]), []).append(h)
        sessions = [{"project": k[0], "sid": k[1], "sid_short": k[1][:8], "path": k[2],
                     "matches": v[:30], "more": max(0, len(v) - 30), "count": len(v)} for k, v in groups.items()]
        ctx.update({"hits": len(hits), "session_count": len({h["session"] for h in hits}), "groups": sessions})
    return render(request, "search.html", "Search", editor=editor_name(), **ctx)

def render_cleanup(request):
    projects = load_projects(); cache = load_cache(); now = datetime.now().timestamp()
    stale = []
    for p in projects:
        age = int(round((now - p["last_active"]) / 86400)) if p["last_active"] else 99999
        if age > 90: stale.append({**p, "age_days": age})
    stale.sort(key=lambda r: -r["size"])
    recoverable = fmt_size(sum(s["size"] for s in stale))
    big = sorted(cache, key=lambda r: -r["size"])[:10]
    return render(request, "cleanup.html", "Cleanup", stale=stale, recoverable=recoverable, big=big,
                  projects_dir=str(CLAUDE / "projects"))

def render_history(request):
    """History & Cache — merges the history-viewer conversation browser with the cache table."""
    q = request.query_params.get("q", "").strip().lower()
    win = request.query_params.get("win", "All time")
    year = request.query_params.get("year", "All")
    include_sub = request.query_params.get("sub") == "1"
    convs = conversation_index(include_sub)
    years = sorted({datetime.fromtimestamp(c["last_ts"]).year for c in convs if c["last_ts"]}, reverse=True)
    if year != "All":
        try:
            yi = int(year); convs = [c for c in convs if c["last_ts"] and datetime.fromtimestamp(c["last_ts"]).year == yi]
        except ValueError: pass
    elif win != "All time":
        days = 30 if win == "30 days" else 7
        cutoff = (datetime.now() - timedelta(days=days)).timestamp()
        convs = [c for c in convs if (c["last_ts"] or 0) >= cutoff]
    content_hits = None
    if q:
        # full-text search folded in: match on preview/project OR message body,
        # ranked so title/preview matches come first, then content-only matches, each by recency
        hit_paths = {h["path"] for h in search_transcripts(q, max_hits=500)}
        content_hits = len(hit_paths)
        def _title_match(c): return q in c["preview"].lower() or q in c["project"].lower()
        matched = [c for c in convs if _title_match(c) or c["path"] in hit_paths]
        matched.sort(key=lambda c: (0 if _title_match(c) else 1, -(c["last_ts"] or 0)))
        convs = matched
    bs = usage_stats().get("by_session", {})
    shown = []
    for c in convs[:400]:
        cost = bs.get(c["session"], {}).get("cost", 0)
        shown.append({**c, "when": fmt_when(c["last_ts"]) if c["last_ts"] else "—",
                      "cost_h": (f"${cost:.2f}" if cost else ""), "path_q": c["path"]})
    total_msgs = sum(c["n"] for c in convs)
    try: all_files = sum(1 for _ in (CLAUDE / "projects").rglob("*.jsonl"))
    except Exception: all_files = 0
    sub_n = max(0, all_files - len(conversation_index()))  # nested sub-agent + workflow transcripts
    cache = load_cache()
    for r in cache: r["path_q"] = r["path"]
    return render(request, "history.html", "History", convs=shown, conv_total=len(convs),
                  total_msgs=total_msgs, win=win, year=year, years=years, q=request.query_params.get("q", ""),
                  content_hits=content_hits, cache=cache, sub_n=sub_n, include_sub=include_sub)

@app.get("/api/conversation", response_class=HTMLResponse)
def api_conversation(request: Request, path: str):
    messages = parse_transcript_messages(path)
    label = transcript_label(path) or "(unnamed conversation)"
    p = Path(path)
    slug = p.parent.name
    project_real = slug.replace("-", "/") if slug.startswith("-") else slug
    sess = usage_stats().get("by_session", {}).get(p.stem, {})
    cost_h = f"${sess['cost']:.2f}" if sess.get("cost") else ""
    return templates.TemplateResponse(request, "_conv_detail.html", {"request": request,
        "theme": theme_of(request), "messages": messages, "label": label, "count": len(messages),
        "path": path, "session": p.stem, "project_real": project_real, "cost_h": cost_h,
        "real_exists": Path(project_real).exists(), "editor": editor_name()})

def render_system(request):
    tab = request.query_params.get("tab", "config")
    return render(request, "system.html", "System", tab=tab, cfg=load_config_detail(), mem=load_memory())

@app.get("/api/memory", response_class=PlainTextResponse)
def api_memory(path: str):
    p = Path(path)
    if "/memory/" not in str(p) or p.suffix != ".md" or not str(p).startswith(str(CLAUDE)):
        return PlainTextResponse("(not a memory file)")
    try: return PlainTextResponse(p.read_text(errors="ignore"))
    except Exception: return PlainTextResponse("(could not read)")

@app.get("/api/palette")
def api_palette(q: str = ""):
    ql = q.lower().strip(); res = []
    for p in PAGES:
        if not ql or ql in p.lower(): res.append({"t": "Page", "label": p, "href": "/p/" + PAGE_SLUG[p]})
    if ql:
        for s in load_skills():
            if ql in s["name"].lower():
                res.append({"t": "Skill", "label": s["name"], "view": s["name"]})
                if len(res) > 28: break
        for c in conversation_index():
            if ql in c["preview"].lower() or ql in c["project"].lower():
                res.append({"t": "Chat", "label": c["preview"][:70],
                            "sub": c["project"].split("/")[-1], "href": "/p/history?conv=" + quote(c["path"])})
                if len(res) > 45: break
    return res[:45]

@app.get("/export/conversation")
def export_conversation(path: str):
    msgs = parse_transcript_messages(path, max_messages=100000)
    label = transcript_label(path) or "conversation"
    out = [f"# {label}\n", f"_Source: {path}_\n"]
    for m in msgs: out.append(f"\n## {m['role']}\n\n{m['text']}\n")
    data = "\n".join(out).encode()
    fn = (re.sub(r"[^A-Za-z0-9_.-]+", "-", label)[:50] or "conversation")
    return StreamingResponse(io.BytesIO(data), media_type="text/markdown",
        headers={"Content-Disposition": f'attachment; filename="{fn}.md"'})

def render_simple(request, title, rows, description):
    q = request.query_params.get("q", "").lower()
    f = rows if not q else [r for r in rows if q in r["name"].lower()]
    filt_size = fmt_size(sum(r["size"] for r in f))
    return render(request, "simple_table.html", title, title=title, rows=f, count=len(f), total=len(rows),
                  filt_size=filt_size, q=q, description=description)

def render_token(request):
    df = aggregate_usage()
    win = request.query_params.get("win", "All time")
    family = request.query_params.get("family", "All")
    d_from = request.query_params.get("from", ""); d_to = request.query_params.get("to", "")
    _today = datetime.now().date().isoformat()  # never allow future dates
    if d_from > _today: d_from = _today
    if d_to > _today: d_to = _today
    if df.empty:
        return render(request, "token.html", "Usage", empty=True, win=win, family=family, d_from=d_from, d_to=d_to, models=["All"])
    df = df.copy()
    df["billable"] = df["input_tokens"] + df["cache_creation"] + df["cache_read"] + df["output_tokens"]
    df["context"] = df["input_tokens"] + df["cache_read"] + df["output_tokens"]
    inp = df["family"].map(lambda f: PRICING[f]["input"]); crp = df["family"].map(lambda f: PRICING[f]["cache_read"])
    df["savings"] = df["cache_read"] * (inp - crp) / 1_000_000
    model_list = sorted(df["label"].dropna().unique().tolist())
    if family != "All":
        df = df[df["label"] == family]
    custom = bool(d_from or d_to)
    if custom and df["date"].notna().any():
        try:
            lo = datetime.fromisoformat(d_from).date() if d_from else datetime(2000, 1, 1).date()
            hi = datetime.fromisoformat(d_to).date() if d_to else datetime.now().date()
            df = df[df["date"].apply(lambda d: bool(d) and lo <= d <= hi)]
        except ValueError: pass
    elif win != "All time" and df["date"].notna().any():
        days = 30 if win == "30 days" else 7
        cutoff = (datetime.now() - timedelta(days=days)).date()
        df = df[df["date"].apply(lambda d: bool(d) and d >= cutoff)]
    if df.empty:
        return render(request, "token.html", "Usage", empty=True, win=win, family=family, d_from=d_from, d_to=d_to, empty_window=True, models=["All"] + model_list)
    cache_total = int(df["cache_read"].sum() + df["cache_creation"].sum())
    cache_hit = (df["cache_read"].sum() / cache_total * 100) if cache_total else 0
    ndays = max(1, df["date"].dropna().nunique())
    proj_monthly = df["cost"].sum() / ndays * 30
    dd = df.dropna(subset=["date"])
    heat = [{"date": str(d), "v": int(v)} for d, v in dd.groupby("date").size().items()]
    metrics1 = [("Billable tokens", fmt_num(df["billable"].sum())), ("Context tokens", fmt_num(df["context"].sum())),
                ("Output", fmt_num(df["output_tokens"].sum())), ("Estimated cost", f"${df['cost'].sum():,.2f}")]
    metrics2 = [("Cache hit rate", f"{cache_hit:.1f}%"), ("Cache saved", f"${df['savings'].sum():,.0f}"),
                ("Proj. monthly", f"${proj_monthly:,.0f}"), ("Turns logged", fmt_num(len(df)))]
    day_chart = None
    if df["date"].notna().any():
        bd = df.dropna(subset=["date"]).groupby(["date", "label"], as_index=False).agg(tokens=("billable", "sum"))
        traces = []
        for lbl in sorted(bd["label"].unique().tolist()):
            sub = bd[bd["label"] == lbl]
            if not sub.empty:
                traces.append({"name": lbl, "x": [str(d) for d in sub["date"]], "y": [int(t) for t in sub["tokens"]], "color": label_color(lbl)})
        day_chart = json.dumps(traces)
    by_proj = df.groupby("project", as_index=False).agg(tokens=("billable", "sum"), cost=("cost", "sum"), turns=("project", "count")).sort_values("cost", ascending=False)
    proj_rows = [{"project": r["project"], "q": r["project"].split("/")[-1], "tokens": fmt_num(r["tokens"]), "cost": f"${r['cost']:.2f}", "turns": int(r["turns"])} for _, r in by_proj.iterrows()]
    by_model = df.groupby("label", as_index=False).agg(cost=("cost", "sum")).sort_values("cost", ascending=False)
    pie = {"labels": list(by_model["label"]), "values": [round(float(c), 2) for c in by_model["cost"]],
           "colors": [label_color(f) for f in by_model["label"]]}
    return render(request, "token.html", "Usage", empty=False, win=win, family=family, d_from=d_from, d_to=d_to,
                  metrics1=metrics1, metrics2=metrics2, day_chart=day_chart, proj_rows=proj_rows,
                  pie=json.dumps(pie), pricing=json.dumps(PRICING, indent=2),
                  heat=json.dumps(heat), models=["All"] + model_list)

def render_sunburst(request):
    rows = []
    for r in load_skills():    rows.append(("Skills", r["name"], int(r["size"]), r["path"]))
    for r in load_projects():  rows.append(("Sessions", r["project"], int(r["size"]), r["path"]))
    for r in load_config_files(): rows.append(("Config", r["name"], int(r["size"]), r["path"]))
    for r in load_cache():     rows.append(("Cache", r["name"], int(r["size"]), r["path"]))
    for r in load_tasks():     rows.append(("Tasks", r["name"], int(r["size"]), r["path"]))
    rows = [r for r in rows if r[2] > 0]
    cats = {}
    for cat, name, size, path in rows: cats.setdefault(cat, 0); cats[cat] += size
    grand = sum(cats.values())
    labels = ["My Claude"]; parents = [""]; values = [grand]; colors = ["#888"]; customdata = [[fmt_size(grand), ""]]
    for cat, tot in cats.items():
        labels.append(cat); parents.append("My Claude"); values.append(tot)
        colors.append(CAT_COLOR.get(cat, "#888")); customdata.append([fmt_size(tot), ""])
    for cat, name, size, path in rows:
        labels.append(name); parents.append(cat); values.append(size)
        colors.append(CAT_COLOR.get(cat, "#888")); customdata.append([fmt_size(size), path])
    data = {"labels": labels, "parents": parents, "values": values, "colors": colors, "customdata": customdata}
    return render(request, "sunburst.html", "Sunburst", data=json.dumps(data))

def render_graph(request):
    try: top_n = int(request.query_params.get("top_n", "15"))
    except ValueError: top_n = 15
    top_n = min(max(5, top_n), 50)
    is_dark = theme_of(request) == "dark"
    edge_c = "#4a4238" if is_dark else "#cbc0ad"; edge_l = "#322C25" if is_dark else "#E5DDD0"
    fg = "#EDE6DC" if is_dark else "#201C17"
    nodes = [{"id": "ROOT", "label": "My Claude", "color": fg, "size": 42}]
    edges = []
    skills = sorted(load_skills(), key=lambda r: -r["size"])[:top_n]
    cat_data = {"Skills": [(s["name"], s["size"], s["path"]) for s in skills],
                "Sessions": [(p["project"], p["size"], p["path"]) for p in load_projects()[:top_n]],
                "Config": [(c["name"], c["size"], c["path"]) for c in load_config_files()[:top_n]],
                "Cache": [(c["name"], c["size"], c["path"]) for c in load_cache()[:top_n]],
                "Tasks": [(t["name"], t["size"], t["path"]) for t in load_tasks()[:top_n]]}
    for cat, items in cat_data.items():
        cid = f"CAT_{cat}"; tot = sum(s for _, s, _ in items)
        nodes.append({"id": cid, "label": f"{cat} ({len(items)})", "color": CAT_COLOR[cat], "size": 30, "title": f"{cat}: {len(items)} items · {fmt_size(tot)}"})
        edges.append({"from": "ROOT", "to": cid, "color": edge_c, "width": 2})
        for name, sz, path in items:
            ns = max(8, min(28, 8 + (sz ** 0.25) / 2))
            nid = f"{cat}_{name}"
            nodes.append({"id": nid, "label": name[:32], "color": CAT_COLOR[cat], "size": ns, "title": f"{name}\n{fmt_size(sz)}\n{path}"})
            edges.append({"from": cid, "to": nid, "color": edge_l, "width": 1})
    connectors = load_connectors(); plugins = load_plugins()
    nodes.append({"id": "CAT_Connectors", "label": f"Connectors ({len(connectors)})", "color": CAT_COLOR["Connectors"], "size": 26})
    edges.append({"from": "ROOT", "to": "CAT_Connectors", "color": edge_c, "width": 2})
    for c in connectors:
        nodes.append({"id": f"MCP_{c['name']}", "label": c["name"], "color": CAT_COLOR["Connectors"], "size": 14, "title": c["name"]})
        edges.append({"from": "CAT_Connectors", "to": f"MCP_{c['name']}", "color": edge_l, "width": 1})
    nodes.append({"id": "CAT_Plugins", "label": f"Plugins ({len(plugins)})", "color": CAT_COLOR["Plugins"], "size": 24})
    edges.append({"from": "ROOT", "to": "CAT_Plugins", "color": edge_c, "width": 2})
    for p in plugins:
        nodes.append({"id": f"PLG_{p['name']}", "label": p["name"], "color": CAT_COLOR["Plugins"], "size": 12, "title": p["name"]})
        edges.append({"from": "CAT_Plugins", "to": f"PLG_{p['name']}", "color": edge_l, "width": 1})
    graph = {"nodes": nodes, "edges": edges, "bg": "#14110D" if is_dark else "#F7F4EE", "font": fg}
    return render(request, "graph.html", "Graph", graph=json.dumps(graph), top_n=top_n)

def render_help(request):
    sections = [
        ("Overview", "overview", "Skills, conversations, token spend, and disk footprint at a glance.",
         ["Tiles summarise skills, conversations, tokens, and storage.",
          "The token tile shows the last 30 days; the Usage page has all-time and custom windows.",
          "Below the tiles: recent conversations, recently updated skills, and anything needing attention."]),
        ("Skills", "skills", "Capabilities loaded into Claude, one folder each.",
         ["Each skill is a folder under ~/.claude/skills/ with a SKILL.md and optional scripts.",
          "Filter by user-created vs plugin-installed; usage counts come from your transcripts.",
          "View reads the full SKILL.md; Push snapshots it to a GitHub repo; Share downloads a portable .zip."]),
        ("MCP & Plugins", "mcp-plugins", "External tool servers and installed plugin bundles.",
         ["Scoped to Claude Code: read from ~/.claude.json and per-project .mcp.json.",
          "Claude Desktop and claude.ai web connectors are configured separately and are not shown here.",
          "Connectors are tool servers wired in via the Model Context Protocol; secrets are auto-redacted. Check health pings each one.",
          "Plugins are bundles installed with /plugin, each shipping skills, commands, or hooks."]),
        ("Usage", "usage", "Token spend and estimated cost, parsed from local transcripts.",
         ["Aggregated from each turn's usage block across every transcript.",
          "Billable is what you'd be charged for; context is what the model saw.",
          "Cost uses Anthropic's public pricing; pick a time window or model family to filter."]),
        ("History", "history", "Browse and read your full conversation history.",
         ["Search message text, filter by time, and read any transcript in a two-pane viewer.",
          "Export to Markdown, resume in Claude, or open the file on disk.",
          "The Caches section lists the performance caches Claude rebuilds as needed."]),
        ("System", "system", "Config and Memory that shape how Claude behaves.",
         ["Config shows your permission rules (allow/ask/deny), hook events, and renders CLAUDE.md.",
          "Edit CLAUDE.md in place; a backup is kept and you confirm before saving.",
          "Memory browses the persistent notes Claude carries between sessions."]),
        ("Command palette", "palette", "Jump anywhere with the keyboard.",
         ["Press Cmd-K (or Ctrl-K) anywhere.",
          "Jump to a page or search across skills and conversations."]),
        ("Settings", "settings", "GitHub push defaults, in the sidebar.",
         ["Set default owner, repo prefix, visibility, and commit template.",
          "Uses your existing gh CLI login; no tokens are stored."]),
    ]
    return render(request, "help.html", "Help", sections=sections)

# ---------- routes: dialogs (HTML partials) ----------
@app.get("/dialog/view/{name}", response_class=HTMLResponse)
def dialog_view(request: Request, name: str):
    path = str(CLAUDE / "skills" / name); meta = parse_skill_meta(path)
    return templates.TemplateResponse(request, "_dlg_view.html", {"request": request, "theme": theme_of(request),
        "name": name, "path": path, "meta": meta})

@app.get("/dialog/transcript", response_class=HTMLResponse)
def dialog_transcript(request: Request, path: str):
    messages = parse_transcript_messages(path)
    label = transcript_label(path) or "(unnamed)"
    return templates.TemplateResponse(request, "_dlg_transcript.html", {"request": request, "theme": theme_of(request),
        "messages": messages, "path": path, "label": label, "count": len(messages)})

@app.get("/dialog/push/{name}", response_class=HTMLResponse)
def dialog_push(request: Request, name: str):
    cfg = load_config_dict(); auth = gh_auth_status(); path = str(CLAUDE / "skills" / name)
    owner = cfg.get("github_owner") or auth["user"] or ""
    repo = (cfg.get("repo_prefix") or "") + name
    exists = gh_repo_exists(owner, repo) if owner else False
    secrets = scan_skill_secrets(path) if owner else []
    return templates.TemplateResponse(request, "_dlg_push.html", {"request": request, "theme": theme_of(request),
        "name": name, "path": path, "auth": auth, "owner": owner, "repo": repo, "exists": exists,
        "visibility": cfg.get("default_visibility", "private"), "secrets": secrets})

@app.get("/dialog/share/{name}", response_class=HTMLResponse)
def dialog_share(request: Request, name: str):
    cfg = load_config_dict(); path = str(CLAUDE / "skills" / name)
    return templates.TemplateResponse(request, "_dlg_share.html", {"request": request, "theme": theme_of(request),
        "name": name, "path": path, "pushed_url": (cfg.get("pushed_skills") or {}).get(name, "")})

@app.get("/dialog/settings", response_class=HTMLResponse)
def dialog_settings(request: Request):
    cfg = load_config_dict(); auth = gh_auth_status()
    return templates.TemplateResponse(request, "_dlg_settings.html", {"request": request, "theme": theme_of(request),
        "cfg": cfg, "auth": auth, "config_path": str(CONFIG_PATH), "config_json": json.dumps(cfg, indent=2)})

@app.get("/dialog/install", response_class=HTMLResponse)
def dialog_install(request: Request):
    return templates.TemplateResponse(request, "_dlg_install.html", {"request": request, "theme": theme_of(request)})

# ---------- routes: actions (JSON) ----------
# NOTE: specific /action/* routes MUST be declared before the catch-all /action/{kind},
# otherwise Starlette matches the catch-all first and returns "unknown action".
@app.post("/action/push")
async def action_push(request: Request):
    d = await request.json()
    name = d["name"]; path = str(CLAUDE / "skills" / name)
    ok, url, log = push_skill_to_github(path, d["owner"], d["repo"], d.get("visibility", "private"))
    if ok:
        cfg = load_config_dict(); cfg.setdefault("pushed_skills", {})[name] = url; save_config(cfg)
        if url: pbcopy(url)
    return {"ok": ok, "url": url, "log": log}

@app.post("/action/install")
async def action_install(request: Request):
    d = await request.json()
    ok, nm, log = install_skill_from_url(d.get("url", ""), d.get("name") or None)
    if ok: clear_cache()
    return {"ok": ok, "name": nm, "log": log}

@app.post("/action/save-claudemd")
async def action_save_claudemd(request: Request):
    d = await request.json()
    content = d.get("content", "")
    cm = CLAUDE / "CLAUDE.md"
    try:
        if cm.exists(): shutil.copy2(str(cm), str(cm) + ".bak")  # keep a backup before overwriting
        cm.write_text(content)
        clear_cache()
        return {"ok": True, "msg": "Saved. Previous version backed up to CLAUDE.md.bak"}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

@app.post("/action/gh-login")
async def action_gh_login(request: Request):
    return gh_login_start()

@app.get("/action/gh-login-status")
async def action_gh_login_status(request: Request):
    st = gh_login_status()
    if st["logged_in"]: clear_cache()  # refresh push-availability across the app once connected
    return st

@app.post("/action/gh-logout")
async def action_gh_logout(request: Request):
    body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
    host = (body.get("host") or "github.com").strip()
    user = (body.get("user") or "").strip()
    cmd = ["gh", "auth", "logout", "--hostname", host]
    if user: cmd += ["--user", user]  # required when multiple accounts are logged in
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        ok = r.returncode == 0
        if ok:
            clear_cache()  # drop the cached gh_auth_status so the reopened dialog + chip show fresh state
            with _gh_lock: _gh_release(kill=True); _gh_login["state"] = "idle"; _gh_login["code"] = None
        msg = (r.stderr or r.stdout or "").strip() or (f"Signed out of {host}." if ok else "Logout failed.")
        return {"ok": ok, "msg": msg[:400]}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

@app.post("/action/{kind}")
async def action(kind: str, request: Request):
    body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
    path = body.get("path", ""); resume = body.get("resume")
    if kind == "finder": return {"ok": open_in_finder(path), "msg": "Opened in Finder"}
    if kind == "terminal": return {"ok": open_in_terminal(path), "msg": f"Opened Terminal at {path}"}
    if kind == "reveal": return {"ok": reveal(path), "msg": "Revealed"}
    if kind == "editor": return {"ok": open_file_default(path), "msg": f"Opened in {editor_name()}"}
    if kind == "copy": return {"ok": pbcopy(body.get("text", path)), "msg": "Copied"}
    if kind == "copyfile":
        try: return {"ok": pbcopy(Path(path).read_text(errors="ignore")), "msg": "Copied to clipboard"}
        except Exception as e: return {"ok": False, "msg": f"Failed: {e}"}
    if kind == "claude": return {"ok": start_claude_in_project(path, resume_id=resume), "msg": "Launching Claude in Terminal…"}
    return {"ok": False, "msg": "unknown action"}

@app.post("/settings/save")
async def settings_save(github_owner: str = Form(""), repo_prefix: str = Form("claude-skill-"),
                        default_visibility: str = Form("private"), commit_message_template: str = Form("Update {skill} skill")):
    cfg = load_config_dict()
    cfg.update({"github_owner": github_owner.strip(), "repo_prefix": repo_prefix.strip(),
                "default_visibility": default_visibility, "commit_message_template": commit_message_template.strip()})
    save_config(cfg); clear_cache()
    return {"ok": True, "msg": "Saved"}

@app.get("/download/skill/{name}.zip")
def download_zip(name: str):
    path = CLAUDE / "skills" / name
    data = make_skill_zip(str(path))
    return StreamingResponse(io.BytesIO(data), media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{name}.zip"'})
